export { default, SculpturalPendantNecklace } from './SculpturalPendantNecklace'
