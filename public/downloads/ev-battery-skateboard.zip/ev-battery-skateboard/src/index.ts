export { default, EVBatterySkateboard } from './EVBatterySkateboard'
