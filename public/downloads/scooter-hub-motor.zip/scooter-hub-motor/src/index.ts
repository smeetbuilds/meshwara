export { default, ScooterHubMotor } from './ScooterHubMotor'
