# MESHVARA / EV Charging Pedestal

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology

A freestanding charging pedestal with calm display, docked connector and curve-authored cable.

An electric-mobility infrastructure object designed as a complete product rather than a box with a plug. Cable sag, connector placement and display hierarchy are tuned for premium transportation interfaces.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/EVChargingPedestal.tsx` into your project, then render `<EVChargingPedestal />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
