export { default, EVChargingPedestal } from './EVChargingPedestal'
