# MESHVARA / Kinetic Archive

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Objects

A stacked mechanical archive with an offset spine and a single signal light.

A disciplined modular object built from weighted slabs rather than decorative noise. The silhouette remains readable at compact card size and on narrow mobile crops.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/KineticArchive.tsx` into your project, then render `<KineticArchive />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
