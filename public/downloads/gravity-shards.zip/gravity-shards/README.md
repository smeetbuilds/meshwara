# MESHVARA / Gravity Shards

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Particles

A composed cloud of glass-like fragments held in an orbital field.

An instanced shard system with disciplined spacing and layered motion. It reads as a designed object rather than a generic particle cloud.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/GravityShards.tsx` into your project, then render `<GravityShards />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
