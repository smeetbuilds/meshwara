export { default, RoomDivider } from './RoomDivider'
