export { default, FoxStudy } from './FoxStudy'
