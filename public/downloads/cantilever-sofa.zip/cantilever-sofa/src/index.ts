export { default, CantileverSofa } from './CantileverSofa'
