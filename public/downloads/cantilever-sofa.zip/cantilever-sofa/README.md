# MESHVARA / Cantilever Sofa

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Furniture

A soft two-seat sofa with restrained cushion separation, dark cantilever structure and one warm accent cushion.

An interior-product study built around upholstery volume, seat/back relationship and a visually light structural base. Suitable for architecture and furniture layouts that need a complete focal object.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/CantileverSofa.tsx` into your project, then render `<CantileverSofa />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
