# MESHVARA / Torque Wrench

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Tools

A long-form torque wrench with ratchet head, knurled adjustment grip and calibrated shaft.

A workshop tool modeled around real mechanical proportions and strong silhouette for automotive and industrial interfaces.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/TorqueWrench.tsx` into your project, then render `<TorqueWrench />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
