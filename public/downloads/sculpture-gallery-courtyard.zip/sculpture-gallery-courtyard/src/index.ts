export { default, SculptureGalleryCourtyard } from './SculptureGalleryCourtyard'
