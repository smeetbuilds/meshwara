export { default, DiningTable } from './DiningTable'
