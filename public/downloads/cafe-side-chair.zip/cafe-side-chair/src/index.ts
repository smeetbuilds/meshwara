export { default, CafeSideChair } from './CafeSideChair'
