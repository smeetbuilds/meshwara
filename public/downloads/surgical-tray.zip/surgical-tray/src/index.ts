export { default, SurgicalInstrumentTray } from './SurgicalInstrumentTray'
