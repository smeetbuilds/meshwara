# MESHVARA / Concert Cello

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Objects

A warm wood cello with custom hourglass body, neck, bridge, strings and grounded endpin.

An instrument study where body contour, material warmth and vertical balance are authored as one object. It is suitable for music, culture and editorial storytelling without relying on a downloaded model.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ConcertCello.tsx` into your project, then render `<ConcertCello />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
