# MESHVARA / Infusion Pump

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Medical

A pole-mounted infusion system with translucent fluid bag, compact pump body and calm clinical display.

A medical-device asset designed around believable support geometry and restrained interface lighting. It is presentation-ready for healthcare, diagnostics and hospital-system layouts.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/InfusionPump.tsx` into your project, then render `<InfusionPump />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
