export { default, ProstheticHand } from './ProstheticHand'
