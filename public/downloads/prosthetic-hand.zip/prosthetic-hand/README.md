# MESHVARA / Prosthetic Hand

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Medical

A technical prosthetic hand study with articulated finger chains, palm shell, thumb linkage and wrist collar.

A medical-device asset rather than a biological hand claim. The mechanical digit hierarchy is explicit and readable, making it suitable for prosthetics, rehabilitation and healthcare technology interfaces.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ProstheticHand.tsx` into your project, then render `<ProstheticHand />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
