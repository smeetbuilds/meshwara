export { default, CinemaCamera } from './CinemaCamera'
