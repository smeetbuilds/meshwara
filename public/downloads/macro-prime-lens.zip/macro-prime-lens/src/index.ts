export { default, MacroPrimeLens } from './MacroPrimeLens'
