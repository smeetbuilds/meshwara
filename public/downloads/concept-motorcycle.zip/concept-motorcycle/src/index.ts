export { default, ConceptMotorcycle } from './ConceptMotorcycle'
