# MESHVARA / Concept Motorcycle

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Vehicles

A stripped-back motorcycle study with aligned wheelbase, structural frame, tank, fork and engine mass.

A vehicle silhouette composed from real structural relationships instead of decorative cylinders. Wheel centres, frame links, tank volume and cockpit line are intentionally coordinated.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ConceptMotorcycle.tsx` into your project, then render `<ConceptMotorcycle />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
