export { default, UVVisSpectrophotometer } from './UVVisSpectrophotometer'
