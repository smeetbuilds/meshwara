export { default, DigitalTorqueWrench } from './DigitalTorqueWrench'
