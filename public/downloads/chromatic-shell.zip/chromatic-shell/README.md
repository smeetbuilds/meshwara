# MESHVARA / Chromatic Shell

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Materials

A thin iridescent shell that shifts across a controlled spectral range.

A physically-inspired iridescent surface study. The asset is intentionally simple in silhouette so the material itself carries the visual identity.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ChromaticShell.tsx` into your project, then render `<ChromaticShell />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
