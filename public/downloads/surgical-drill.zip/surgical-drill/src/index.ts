export { default, SurgicalDrill } from './SurgicalDrill'
