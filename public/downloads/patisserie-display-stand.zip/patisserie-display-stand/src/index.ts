export { default, PatisserieDisplayStand } from './PatisserieDisplayStand'
