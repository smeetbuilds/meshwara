export { default, AeroCyclingHelmet } from './AeroCyclingHelmet'
