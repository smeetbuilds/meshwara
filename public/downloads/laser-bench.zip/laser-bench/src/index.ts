export { default, OpticalLaserBench } from './OpticalLaserBench'
