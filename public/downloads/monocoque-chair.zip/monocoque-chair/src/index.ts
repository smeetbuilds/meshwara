export { default, MonocoqueChair } from './MonocoqueChair'
