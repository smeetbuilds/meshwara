# MESHVARA / Monocoque Chair

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Furniture

A soft monocoque lounge chair with a quiet shell, dark metal stance and warm structural detail.

A furniture study focused on silhouette, bevel quality and proportion rather than ornamental complexity. Its material hierarchy is designed for product-showcase and interior-editorial compositions.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/MonocoqueChair.tsx` into your project, then render `<MonocoqueChair />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
