# MESHVARA / Nocturne Rings

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Objects

A near-black orbital assembly cut by one electric-violet trace.

A dark, high-contrast kinetic object with carefully varied torus weights and one luminous accent. It is designed to hold shape even against sparse monochrome layouts.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/NocturneRings.tsx` into your project, then render `<NocturneRings />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
