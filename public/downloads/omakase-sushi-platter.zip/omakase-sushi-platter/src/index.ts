export { default, OmakaseSushiPlatter } from './OmakaseSushiPlatter'
