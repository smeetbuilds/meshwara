# MESHVARA / Monarch Butterfly

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Animals

A graphic monarch study with authored wing contour, warm pattern accents and restrained wing motion.

A decorative butterfly asset whose custom wing profile and material treatment hold up in sparse interface compositions. Motion is intentionally stylized and not presented as a scientific flight simulation.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/MonarchButterfly.tsx` into your project, then render `<MonarchButterfly />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
