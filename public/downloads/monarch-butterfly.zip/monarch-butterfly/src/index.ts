export { default, MonarchButterfly } from './MonarchButterfly'
