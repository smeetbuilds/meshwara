export { default, VinylDeck } from './VinylDeck'
