# MESHVARA / Vinyl Deck

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology

A premium turntable with rotating record, machined platter, curved tonearm and restrained control hardware.

An audio-product composition focused on platter depth, record detail, tonearm geometry and material contrast. Motion is limited to the record so the object remains calm enough for editorial layouts.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/VinylDeck.tsx` into your project, then render `<VinylDeck />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
