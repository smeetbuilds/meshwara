export { default, CNCRotaryTable } from './CNCRotaryTable'
