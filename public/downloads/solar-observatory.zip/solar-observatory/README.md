# MESHVARA / Solar Observatory

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Scenes

A compact observatory vignette with raised platform, articulated telescope, technical display and staged solar light.

A complete spatial composition rather than a single object. Architecture, instrument, control display and light source are designed as a reusable editorial scene with restrained autonomous telescope movement.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/SolarObservatory.tsx` into your project, then render `<SolarObservatory />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
