export { default, SolarObservatory } from './SolarObservatory'
