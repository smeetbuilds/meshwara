export { default, PatientMonitor } from './PatientMonitor'
