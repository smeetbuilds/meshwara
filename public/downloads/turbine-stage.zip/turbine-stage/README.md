# MESHVARA / Turbine Stage

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Industrial

A radial turbine study with machined casing, thirty-six repeated blades and a measured rotating core.

A disciplined rotating-machine asset using instanced blade geometry for density without excess draw calls. Material hierarchy and axis alignment are tuned for technical product presentation.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/TurbineStage.tsx` into your project, then render `<TurbineStage />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
