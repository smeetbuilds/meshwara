export { default, GrandPiano } from './GrandPiano'
