# MESHVARA / Grand Piano

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Objects

A black grand piano with custom body profile, raised lid, keyboard and weighted three-leg stance.

A complete musical product object composed around recognizable grand-piano proportions. The custom extruded body keeps the silhouette distinct while restrained material response gives it a premium studio presence.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/GrandPiano.tsx` into your project, then render `<GrandPiano />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
