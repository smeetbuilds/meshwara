export { default, PipetteRack } from './PipetteRack'
