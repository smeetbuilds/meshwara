export { default, LabIncubator } from './LabIncubator'
