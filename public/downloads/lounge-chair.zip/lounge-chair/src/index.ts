export { default, LoungeChair } from './LoungeChair'
