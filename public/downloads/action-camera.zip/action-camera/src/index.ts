export { default, ActionCamera } from './ActionCamera'
