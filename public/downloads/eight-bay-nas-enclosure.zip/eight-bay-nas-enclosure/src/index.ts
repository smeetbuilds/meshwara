export { default, EightBayNASEnclosure } from './EightBayNASEnclosure'
