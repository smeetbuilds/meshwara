export { default, AutomatedDefibrillator } from './AutomatedDefibrillator'
