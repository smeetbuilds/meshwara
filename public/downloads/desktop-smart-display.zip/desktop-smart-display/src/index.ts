export { default, DesktopSmartDisplay } from './DesktopSmartDisplay'
