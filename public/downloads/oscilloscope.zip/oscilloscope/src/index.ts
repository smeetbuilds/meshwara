export { default, DigitalOscilloscope } from './DigitalOscilloscope'
