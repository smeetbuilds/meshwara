# MESHVARA / Digital Oscilloscope

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Scientific / Electronics

A bench oscilloscope with gridded display, channel controls, probe ports and carry handle.

A scientific/electronics instrument with clear control hierarchy and realistic benchtop proportions for lab scenes.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/DigitalOscilloscope.tsx` into your project, then render `<DigitalOscilloscope />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
