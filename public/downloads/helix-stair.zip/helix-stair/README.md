# MESHVARA / Helix Stair

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Architecture

A compact spiral stair with disciplined tread spacing, slim structure and a gallery-scale architectural footprint.

An architectural component built from deterministic repeated geometry and a central structural spine. The stair reads as a spatial object at both catalog and hero scale without unnecessary room geometry.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/HelixStair.tsx` into your project, then render `<HelixStair />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
