# MESHVARA / Mushroom Cluster

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Nature

A five-form woodland mushroom cluster with varied cap scale, stem height and grounded earth base.

A compact organic composition designed as a coherent cluster instead of copied identical mushrooms. Variation comes from authored proportions and placement, not runtime randomness.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/MushroomCluster.tsx` into your project, then render `<MushroomCluster />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
