# MESHVARA / Spectral Membrane

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Shaders

A breathing interference shell whose color emerges from view angle and deformation.

A translucent fresnel-driven shader study with controlled spectral interference and subtle normal-direction deformation. Built as a focal object, not a generic rainbow sphere.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/SpectralMembrane.tsx` into your project, then render `<SpectralMembrane />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
