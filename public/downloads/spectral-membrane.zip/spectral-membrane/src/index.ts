export { default, SpectralMembrane } from './SpectralMembrane'
