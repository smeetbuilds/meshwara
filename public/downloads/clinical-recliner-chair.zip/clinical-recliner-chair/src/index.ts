export { default, ClinicalReclinerChair } from './ClinicalReclinerChair'
