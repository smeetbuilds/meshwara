export { default, PerformanceRoadBike } from './PerformanceRoadBike'
