# MESHVARA / Hydraulic Press

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Industrial

A compact H-frame hydraulic press with weighted uprights, ram, platen and local control module.

An industrial machine asset where structural hierarchy is explicit: base, columns, crown, ram and working table. Proportions remain readable at both card and hero scale.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/HydraulicPress.tsx` into your project, then render `<HydraulicPress />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
