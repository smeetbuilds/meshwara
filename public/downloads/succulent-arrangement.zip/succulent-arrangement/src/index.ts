export { default, SucculentArrangement } from './SucculentArrangement'
