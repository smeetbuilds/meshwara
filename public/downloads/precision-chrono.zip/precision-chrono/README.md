# MESHVARA / Precision Chrono

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Fashion

A machined chronograph study with layered dial depth, optical crystal and measured mechanical motion.

A product-focused watch composition built from a dense case, transmission crystal, instanced index marks, subdials and calibrated hand motion. Intended for premium fashion and industrial-design hero layouts.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/PrecisionChrono.tsx` into your project, then render `<PrecisionChrono />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
