export { default, ArcWallSconce } from './ArcWallSconce'
