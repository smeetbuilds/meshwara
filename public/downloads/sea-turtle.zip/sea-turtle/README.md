# MESHVARA / Sea Turtle

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Animals

A broad-shelled turtle study with layered scutes, tapered head and four flattened swimming limbs.

A stylized marine animal built for readable silhouette at card scale. Shell volume and limb placement are more important than surface noise, making it useful in calm environmental and educational compositions.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/SeaTurtle.tsx` into your project, then render `<SeaTurtle />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
