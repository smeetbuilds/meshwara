export { default, PerformanceCornerAssembly } from './PerformanceCornerAssembly'
