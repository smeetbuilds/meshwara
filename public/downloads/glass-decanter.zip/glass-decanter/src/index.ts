export { default, GlassDecanter } from './GlassDecanter'
