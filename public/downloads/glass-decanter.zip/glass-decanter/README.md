# MESHVARA / Glass Decanter

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Glass

A thick optical decanter with amber inner volume, faceted stopper and a weighted metal foot.

A glass-and-liquid presentation object tuned around thickness, refraction, inner volume and silhouette. Designed for hospitality, fragrance-adjacent and luxury product contexts.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/GlassDecanter.tsx` into your project, then render `<GlassDecanter />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
