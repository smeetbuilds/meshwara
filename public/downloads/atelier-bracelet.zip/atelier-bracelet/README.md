# MESHVARA / Atelier Bracelet

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Jewelry

A sixteen-link bracelet alternating warm and cool metal across a softly irregular closed chain.

A deterministic chain study built from individually oriented links rather than a generic torus. Subtle depth offsets make the bracelet feel handled while preserving a deliberate luxury silhouette.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/AtelierBracelet.tsx` into your project, then render `<AtelierBracelet />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
