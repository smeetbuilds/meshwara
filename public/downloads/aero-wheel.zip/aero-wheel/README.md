# MESHVARA / Aero Wheel

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Vehicles / Components

A forged aerodynamic wheel with deep rim, directional spokes and performance tire profile.

A close-up automotive component with radial spoke logic, proper wheel axis and layered hub/brake volumes.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/AeroWheel.tsx` into your project, then render `<AeroWheel />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
