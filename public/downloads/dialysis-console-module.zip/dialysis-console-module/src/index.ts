export { default, DialysisConsoleModule } from './DialysisConsoleModule'
