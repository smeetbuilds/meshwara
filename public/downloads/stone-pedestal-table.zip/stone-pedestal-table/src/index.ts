export { default, StonePedestalTable } from './StonePedestalTable'
