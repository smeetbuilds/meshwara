# MESHVARA / Writing Desk

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Furniture / Tables

A slim writing desk with inset leather surface, shallow drawer and tapered frame.

A workspace furniture asset with disciplined proportions, modest hardware and enough detail to hold up in medium-close product scenes.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/WritingDesk.tsx` into your project, then render `<WritingDesk />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
