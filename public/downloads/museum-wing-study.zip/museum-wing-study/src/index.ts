export { default, MuseumWingStudy } from './MuseumWingStudy'
