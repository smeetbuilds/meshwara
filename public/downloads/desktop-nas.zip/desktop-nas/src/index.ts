export { default, DesktopNAS } from './DesktopNAS'
