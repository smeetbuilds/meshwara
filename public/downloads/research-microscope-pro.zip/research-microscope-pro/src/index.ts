export { default, ResearchMicroscopePro } from './ResearchMicroscopePro'
