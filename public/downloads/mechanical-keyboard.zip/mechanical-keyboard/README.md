# MESHVARA / Mechanical Keyboard

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology

A compact mechanical keyboard with deterministic key layout, machined enclosure and one quiet status line.

A desk-hardware asset built with instanced key geometry for density without unnecessary draw calls. Row offsets and key proportions are composed to read as a real keyboard rather than a tiled grid.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/MechanicalKeyboard.tsx` into your project, then render `<MechanicalKeyboard />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
