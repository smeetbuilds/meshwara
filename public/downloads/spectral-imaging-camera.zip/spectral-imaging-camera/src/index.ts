export { default, SpectralImagingCamera } from './SpectralImagingCamera'
