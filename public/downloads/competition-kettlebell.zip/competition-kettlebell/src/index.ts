export { default, CompetitionKettlebell } from './CompetitionKettlebell'
