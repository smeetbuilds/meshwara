export { default, GrandTouringCoupe } from './GrandTouringCoupe'
