export { default, ThreeAxisGimbal } from './ThreeAxisGimbal'
