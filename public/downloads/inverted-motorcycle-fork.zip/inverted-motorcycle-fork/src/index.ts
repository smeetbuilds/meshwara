export { default, InvertedMotorcycleFork } from './InvertedMotorcycleFork'
