export { default, ModularSmartphone } from './ModularSmartphone'
