export { default, MagneticStirrer } from './MagneticStirrer'
