# MESHVARA / Koi Pair

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Animals

Two restrained koi orbit a shallow water plane with opposing color, fin and body rhythms.

A decorative aquatic composition using paired movement and deliberately offset spacing. The animation is atmospheric rather than sold as biological locomotion, keeping the asset honest and usable for editorial scenes.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/KoiPair.tsx` into your project, then render `<KoiPair />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
