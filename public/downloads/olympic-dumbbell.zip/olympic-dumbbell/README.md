# MESHVARA / Olympic Dumbbell

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Sports

A gym dumbbell with knurled grip zone, stepped collars and symmetrical weighted ends.

A compact strength-training object designed for fitness, performance and wellness interfaces.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/OlympicDumbbell.tsx` into your project, then render `<OlympicDumbbell />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
