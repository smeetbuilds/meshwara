export { default, OlympicDumbbell } from './OlympicDumbbell'
