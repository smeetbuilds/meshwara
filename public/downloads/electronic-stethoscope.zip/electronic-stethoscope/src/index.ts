export { default, ElectronicStethoscope } from './ElectronicStethoscope'
