# MESHVARA / Electric Drive

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Vehicles

A cutaway electric-drive study with copper windings, machined rotor and a restrained mechanical rotation.

A technical automotive object centered on stator rhythm, rotor hierarchy and material legibility. Repeated coil details are instanced to preserve density without unnecessary draw-call cost.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ElectricDrive.tsx` into your project, then render `<ElectricDrive />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
