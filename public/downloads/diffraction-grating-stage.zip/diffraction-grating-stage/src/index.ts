export { default, DiffractionGratingStage } from './DiffractionGratingStage'
