export { default, TramSeatModule } from './TramSeatModule'
