export { default, MagneticChargingDock } from './MagneticChargingDock'
