import { Bounds, Environment, Float, Lightformer } from '@react-three/drei'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { Suspense, useEffect, useRef, useState, type ReactNode } from 'react'
import * as THREE from 'three'
import SceneObject from './Scene'

function useReducedMotion() {
  const [reduced, setReduced] = useState(false)
  useEffect(() => {
    const media = window.matchMedia('(prefers-reduced-motion: reduce)')
    const sync = () => setReduced(media.matches)
    sync()
    media.addEventListener('change', sync)
    return () => media.removeEventListener('change', sync)
  }, [])
  return reduced
}

function Rig({ children, enabled }: { children: ReactNode; enabled: boolean }) {
  const ref = useRef<THREE.Group>(null)
  const { pointer } = useThree()
  useFrame((_, delta) => {
    if (!ref.current || !enabled) return
    ref.current.rotation.y = THREE.MathUtils.damp(ref.current.rotation.y, pointer.x * 0.18, 4.2, delta)
    ref.current.rotation.x = THREE.MathUtils.damp(ref.current.rotation.x, pointer.y * -0.1, 4.2, delta)
  })
  return <group ref={ref}>{children}</group>
}

function Studio() {
  return (
    <>
      <hemisphereLight color="#fffdf8" groundColor="#a8a49b" intensity={1.15} />
      <directionalLight position={[5.5, 6.5, 4.5]} intensity={2.6} />
      <directionalLight position={[-4.5, 2.2, -3.5]} intensity={1.3} />
      <pointLight position={[0, -1.6, 3.6]} intensity={0.55} distance={8} />
      <Environment resolution={160}>
        <Lightformer intensity={4.6} position={[0, 5, -2]} scale={[8, 1.6, 1]} />
        <Lightformer intensity={3.2} position={[-5, 0.5, 2]} rotation-y={Math.PI / 2} scale={[6, 1.5, 1]} />
        <Lightformer intensity={2.6} position={[5, -0.6, 1]} rotation-y={-Math.PI / 2} scale={[5, 1.1, 1]} />
      </Environment>
    </>
  )
}

export function MagneticChargingDock() {
  const reducedMotion = useReducedMotion()
  return (
    <Canvas
      dpr={[1, 2]}
      gl={{ antialias: true, alpha: true, powerPreference: 'high-performance' }}
      camera={{ position: [0, 0, 4.8], fov: 34, near: 0.05, far: 120 }}
      frameloop={reducedMotion ? 'demand' : 'always'}
      onCreated={({ gl }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping
        gl.toneMappingExposure = 1.08
        gl.outputColorSpace = THREE.SRGBColorSpace
      }}
    >
      <Suspense fallback={null}>
        <Studio />
        <Bounds fit clip observe margin={1.16}>
          <Rig enabled={!reducedMotion && true}>
          <SceneObject />
        </Rig>
        </Bounds>
      </Suspense>
    </Canvas>
  )
}

export default MagneticChargingDock
