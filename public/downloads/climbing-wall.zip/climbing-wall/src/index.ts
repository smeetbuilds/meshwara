export { default, ClimbingWall } from './ClimbingWall'
