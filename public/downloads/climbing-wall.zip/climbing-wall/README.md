# MESHVARA / Climbing Wall

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Sports

A freestanding climbing-wall study with faceted panels, authored hold placements and grounded frame.

A sports-environment asset composed as a complete vertical training object rather than a loose set of holds.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ClimbingWall.tsx` into your project, then render `<ClimbingWall />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
