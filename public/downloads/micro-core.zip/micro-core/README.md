# MESHVARA / Micro Core

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology

A compact processor package with shared pin geometry, machined layers and a luminous center.

A hardware-focused object using instancing for repeated contacts and a deliberately sparse emissive treatment. Built to remain readable in small technical cards and larger launch compositions.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/MicroCore.tsx` into your project, then render `<MicroCore />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
