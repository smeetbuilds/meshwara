export { default, StudioDumbbellPair } from './StudioDumbbellPair'
