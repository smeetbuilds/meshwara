export { default, UrbanElectricScooter } from './UrbanElectricScooter'
