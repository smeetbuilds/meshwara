export { default, ICUVentilator } from './ICUVentilator'
