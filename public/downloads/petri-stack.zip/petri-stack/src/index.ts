export { default, PetriDishStack } from './PetriDishStack'
