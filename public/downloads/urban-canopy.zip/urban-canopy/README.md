# MESHVARA / Urban Canopy

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Architecture

A light public canopy with custom curved roof profile, four metal supports and integrated bench.

An urban-space micro-architecture asset built from one authored roof shape and minimal supporting structure. The silhouette is intentionally different from the library’s pavilion and cabin typologies.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/UrbanCanopy.tsx` into your project, then render `<UrbanCanopy />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
