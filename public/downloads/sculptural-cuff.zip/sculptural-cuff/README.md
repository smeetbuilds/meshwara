# MESHVARA / Sculptural Cuff

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Jewelry

An open warm-metal cuff with softened terminals and a fine engraved halo detail.

A close-up jewelry object designed around controlled opening angle, terminal weight and highly polished material response. Suitable for luxury fashion and product storytelling.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/SculpturalCuff.tsx` into your project, then render `<SculpturalCuff />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
