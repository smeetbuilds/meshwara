export { default, EmperorPenguin } from './EmperorPenguin'
