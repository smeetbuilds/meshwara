export { default, TourTennisRacket } from './TourTennisRacket'
