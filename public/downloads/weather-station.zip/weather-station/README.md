# MESHVARA / Weather Station

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Scientific

A compact field station with rotating cup anemometer, wind vane, shielded sensor stack and weighted mast.

A scientific-instrument asset that communicates function through visible sensor hierarchy. The slow anemometer motion is mechanically meaningful rather than decorative.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/WeatherStation.tsx` into your project, then render `<WeatherStation />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
