# MESHVARA / Pressure Valve

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Industrial

A flanged process valve with cast body, rising stem and a six-spoke brass handwheel.

A process-engineering object built around recognisable flange, bonnet and wheel proportions. The component reads as industrial hardware without falling back on sci-fi ornamentation.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/PressureValve.tsx` into your project, then render `<PressureValve />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
