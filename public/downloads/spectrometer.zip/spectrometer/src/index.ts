export { default, Spectrometer } from './Spectrometer'
