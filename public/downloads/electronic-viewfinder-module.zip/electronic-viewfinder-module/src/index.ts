export { default, ElectronicViewfinderModule } from './ElectronicViewfinderModule'
