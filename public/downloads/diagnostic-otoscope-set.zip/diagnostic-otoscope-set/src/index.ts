export { default, DiagnosticOtoscopeSet } from './DiagnosticOtoscopeSet'
