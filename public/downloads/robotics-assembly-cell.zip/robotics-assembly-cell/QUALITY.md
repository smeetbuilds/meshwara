# Meshvara / visual-fidelity disclosure

- Download and preview source are synchronized.
- Geometry and archive integrity are automated checks, not evidence of photorealism.
- Object likeness, scale, topology and materials still require independent artist review.
- Do not present this asset as an approved scan or certified production model.
