export { default, RoboticsAssemblyCell } from './RoboticsAssemblyCell'
