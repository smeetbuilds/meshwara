export { default, CNCSpindle } from './CNCSpindle'
