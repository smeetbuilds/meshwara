export { default, ServoMotor } from './ServoMotor'
