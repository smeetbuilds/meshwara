# MESHVARA / Reference Turntable

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology / Audio

A belt-drive turntable with isolated platter, tonearm and low-profile plinth.

A hi-fi product asset composed around believable platter mass, cartridge geometry and a controlled tonearm arc rather than decorative audio clichés.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ReferenceTurntable.tsx` into your project, then render `<ReferenceTurntable />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
