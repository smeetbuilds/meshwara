export { default, ModularShelving } from './ModularShelving'
