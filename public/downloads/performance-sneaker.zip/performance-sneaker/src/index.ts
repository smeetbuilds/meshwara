export { default, PerformanceSneaker } from './PerformanceSneaker'
