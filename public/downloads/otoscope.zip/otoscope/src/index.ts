export { default, ClinicalOtoscope } from './ClinicalOtoscope'
