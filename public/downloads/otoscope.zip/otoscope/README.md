# MESHVARA / Clinical Otoscope

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Medical / Diagnostic

A handheld otoscope with tapered speculum, optical head, grip and charging base.

A compact examination tool rendered as a premium clinical product with readable optical and ergonomic construction.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ClinicalOtoscope.tsx` into your project, then render `<ClinicalOtoscope />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
