# MESHVARA / Obsidian Signet

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Jewelry

A warm-metal signet ring with a dark inset face and disciplined engraved halo detail.

A jewelry-focused hero object balancing polished metal, dark mineral surface and compact engraved geometry. Proportions are tuned for close-up fashion and luxury presentation.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ObsidianSignet.tsx` into your project, then render `<ObsidianSignet />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
