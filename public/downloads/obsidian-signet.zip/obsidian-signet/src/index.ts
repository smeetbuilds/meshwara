export { default, ObsidianSignet } from './ObsidianSignet'
