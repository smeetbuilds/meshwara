# MESHVARA / Optical Frames

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Fashion

A thin metal eyewear study with optical lenses, sculpted bridge and long restrained temples.

A fashion accessory built around precise front-plane geometry, lens transmission and lightweight metal proportions. Intended for editorial fashion and product-detail interfaces.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/OpticalFrames.tsx` into your project, then render `<OpticalFrames />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
