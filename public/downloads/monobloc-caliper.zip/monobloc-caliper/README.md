# MESHVARA / Monobloc Brake Caliper

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Vehicles / Components

A monobloc brake caliper with bridged body, piston bosses and machined mounting ears.

A MESHVARA components asset built as a self-contained Three.js composition with authored proportions, deterministic detail and responsive presentation.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/MonoblocBrakeCaliper.tsx` into your project, then render `<MonoblocBrakeCaliper />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
