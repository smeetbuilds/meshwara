# MESHVARA / Electric Coupe

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Vehicles / Road

A low electric coupe silhouette with aero wheels, continuous glasshouse and disciplined lighting signatures.

A stylized-but-product-authored road vehicle that preserves realistic wheelbase, cabin proportion and grounded stance without claiming OEM-specific geometry.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ElectricCoupe.tsx` into your project, then render `<ElectricCoupe />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
