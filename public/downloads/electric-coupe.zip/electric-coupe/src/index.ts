export { default, ElectricCoupe } from './ElectricCoupe'
