export { default, RailPlatformCanopy } from './RailPlatformCanopy'
