export { default, CeilingWiFiAccessPoint } from './CeilingWiFiAccessPoint'
