# MESHVARA / Magnetic Filaments

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Generative

A field of luminous strands bending around an invisible magnetic body.

A generative field study using coherent curves instead of random particles. Built for atmospheric backgrounds and high-end experimental interfaces.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/MagneticFilaments.tsx` into your project, then render `<MagneticFilaments />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
