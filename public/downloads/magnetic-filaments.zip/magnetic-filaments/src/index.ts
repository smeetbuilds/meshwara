export { default, MagneticFilaments } from './MagneticFilaments'
