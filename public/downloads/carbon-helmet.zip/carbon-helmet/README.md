# MESHVARA / Carbon Helmet

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Fashion

A high-gloss protective shell with smoked optical visor, compact chin structure and precision side hardware.

A motorsport-inspired fashion/product object using controlled shell curvature, visor transmission and machined accents. It is intentionally presented as a premium design study rather than a generic sphere-derived helmet.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/CarbonHelmet.tsx` into your project, then render `<CarbonHelmet />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
