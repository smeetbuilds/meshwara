# MESHVARA / Performance Rotor

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Vehicles

A performance brake assembly reduced to its essential rotor, hub, fasteners and caliper geometry.

An automotive component study using repeated drilled detail, machined surfaces and controlled motion to create a technically legible object without unnecessary scene weight.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/PerformanceRotor.tsx` into your project, then render `<PerformanceRotor />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
