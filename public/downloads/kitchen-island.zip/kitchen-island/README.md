# MESHVARA / Kitchen Island

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Scenes

A complete kitchen-island vignette with stone worktop, sink, stools and paired pendant lights.

A deployable interior composition rather than a single cabinet. Counter depth, seating spacing, sink position and light placement are tuned as one believable domestic scene.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/KitchenIsland.tsx` into your project, then render `<KitchenIsland />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
