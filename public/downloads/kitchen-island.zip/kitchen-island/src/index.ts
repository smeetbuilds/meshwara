export { default, KitchenIsland } from './KitchenIsland'
