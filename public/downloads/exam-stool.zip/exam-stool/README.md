# MESHVARA / Clinical Exam Stool

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Medical / Clinical

A height-adjustable exam stool with upholstered seat, gas column and five-caster base.

A clinical furniture object with proper radial caster geometry and a stable, serviceable silhouette.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ClinicalExamStool.tsx` into your project, then render `<ClinicalExamStool />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
