export { default, ClinicalExamStool } from './ClinicalExamStool'
