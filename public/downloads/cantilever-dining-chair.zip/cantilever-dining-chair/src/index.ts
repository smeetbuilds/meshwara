export { default, CantileverDiningChair } from './CantileverDiningChair'
