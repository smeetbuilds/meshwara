# MESHVARA / Cantilever Dining Chair

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Furniture

An upholstered dining chair suspended on a continuous tubular cantilever frame.

A furniture study centered on seat/back proportion and believable metal support geometry. The open frame gives the object a distinctive silhouette without relying on decorative complexity.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/CantileverDiningChair.tsx` into your project, then render `<CantileverDiningChair />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
