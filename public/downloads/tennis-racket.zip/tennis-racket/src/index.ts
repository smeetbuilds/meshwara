export { default, TennisRacket } from './TennisRacket'
