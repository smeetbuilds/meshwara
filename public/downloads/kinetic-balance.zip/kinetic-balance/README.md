# MESHVARA / Kinetic Balance

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Scientific

A precision beam balance with brass fulcrum, paired pans, suspension wires and calibration weights.

A classic measurement-instrument study where symmetry, suspension lines and material hierarchy do the visual work. Designed for education, laboratory and editorial science contexts.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/KineticBalance.tsx` into your project, then render `<KineticBalance />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
