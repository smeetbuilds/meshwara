# MESHVARA / Architect Pen

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Objects

A machined drafting pen with fine knurl rhythm, metal clip, precision tip and one controlled luminous detail.

A compact industrial-design object with carefully separated barrel, cap, clip, tip and grip details. Built for product, stationery and design-tool interfaces where small-scale precision matters.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ArchitectPen.tsx` into your project, then render `<ArchitectPen />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
