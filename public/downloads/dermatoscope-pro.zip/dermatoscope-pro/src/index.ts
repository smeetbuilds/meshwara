export { default, DermatoscopePro } from './DermatoscopePro'
