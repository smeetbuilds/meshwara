export { default, RedDeerStudy } from './RedDeerStudy'
