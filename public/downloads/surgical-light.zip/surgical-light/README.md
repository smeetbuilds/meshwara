# MESHVARA / Surgical Light

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Medical

A dual-head surgical lighting system with articulated support arms and radial LED optics.

A clinical-equipment study emphasizing clean mechanical joints, neutral materials and readable lamp geometry. Static presentation keeps it useful as a medical or healthcare interface anchor.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/SurgicalLight.tsx` into your project, then render `<SurgicalLight />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
