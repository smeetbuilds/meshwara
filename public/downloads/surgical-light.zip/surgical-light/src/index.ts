export { default, SurgicalLight } from './SurgicalLight'
