export { default, GalleryStudy } from './GalleryStudy'
