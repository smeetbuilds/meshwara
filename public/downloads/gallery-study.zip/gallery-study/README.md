# MESHVARA / Gallery Study

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Scenes

A complete editorial gallery vignette with architecture, pedestal, optical sculpture and staged light.

A ready-to-use spatial scene rather than a single object: room shell, floor, display pedestal, sculptural centerpiece and deliberate lighting are composed as one deployable hero environment.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/GalleryStudy.tsx` into your project, then render `<GalleryStudy />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
