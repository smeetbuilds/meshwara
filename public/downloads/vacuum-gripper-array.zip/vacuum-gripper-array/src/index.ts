export { default, VacuumGripperArray } from './VacuumGripperArray'
