export { default, CompactNearfieldMonitor } from './CompactNearfieldMonitor'
