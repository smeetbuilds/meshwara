# MESHVARA / Liquid Lens

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Glass

A suspended optical lens that bends the world behind it.

A minimal refractive object with deliberate thickness and subtle pointer inertia. Useful as a visual anchor without requiring a full 3D scene.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/LiquidLens.tsx` into your project, then render `<LiquidLens />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
