export { default, MonsteraStudy } from './MonsteraStudy'
