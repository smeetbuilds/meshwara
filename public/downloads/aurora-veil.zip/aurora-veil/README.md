# MESHVARA / Aurora Veil

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Shaders

A suspended programmable surface carrying a restrained polar-light spectrum.

A custom vertex and fragment shader that behaves like a lit textile membrane instead of a full-screen gradient. The geometry, alpha falloff and color bands are composed for hero use.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/AuroraVeil.tsx` into your project, then render `<AuroraVeil />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
