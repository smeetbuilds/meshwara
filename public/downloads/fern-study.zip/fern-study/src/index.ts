export { default, FernStudy } from './FernStudy'
