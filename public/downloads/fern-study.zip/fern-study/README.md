# MESHVARA / Fern Study

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Nature

Seven curve-authored fronds radiate from a compact planter with layered paired leaflets.

A foliage asset built from explicit frond curves and deterministic leaf placement rather than random instancing. It is designed to remain coherent when viewed close or compressed into a catalog card.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/FernStudy.tsx` into your project, then render `<FernStudy />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
