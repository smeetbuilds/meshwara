# MESHVARA / Roadster Cockpit

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Scenes

A compact two-seat roadster cockpit with leather seating, steering wheel, dashboard and optical windshield.

A complete automotive interior fragment rather than a loose steering-wheel prop. Seating, dashboard depth, glass angle and controls are balanced as one premium mobility scene.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/RoadsterCockpit.tsx` into your project, then render `<RoadsterCockpit />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
