export { default, SpatialHeadset } from './SpatialHeadset'
