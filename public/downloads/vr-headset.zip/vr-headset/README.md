# MESHVARA / Spatial Headset

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology / XR

A spatial-computing headset with continuous visor, facial interface and articulated strap system.

A clean XR hardware study with an optical front volume, soft-contact geometry and balanced strap construction suitable for premium technology presentation.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/SpatialHeadset.tsx` into your project, then render `<SpatialHeadset />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
