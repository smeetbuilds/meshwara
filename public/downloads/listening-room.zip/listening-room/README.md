# MESHVARA / Listening Room

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Scenes

A complete listening-room vignette with paired speakers, soft chair, low console and warm staged light.

A deployable interior scene composed as one quiet audio environment. Spatial scale, speaker symmetry, seat placement and warm lighting are intentionally balanced for full-bleed editorial use.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ListeningRoom.tsx` into your project, then render `<ListeningRoom />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
