export { default, SailboatDeckWinch } from './SailboatDeckWinch'
