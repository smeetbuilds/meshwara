export { default, CeilingLight } from './CeilingLight'
