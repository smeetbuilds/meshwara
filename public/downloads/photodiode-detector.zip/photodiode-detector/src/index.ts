export { default, PhotodiodeDetector } from './PhotodiodeDetector'
