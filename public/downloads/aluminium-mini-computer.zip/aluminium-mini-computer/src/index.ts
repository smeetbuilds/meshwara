export { default, AluminiumMiniComputer } from './AluminiumMiniComputer'
