export { default, HummingbirdStudy } from './HummingbirdStudy'
