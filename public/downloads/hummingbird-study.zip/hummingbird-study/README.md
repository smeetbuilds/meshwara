# MESHVARA / Hummingbird Study

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Animals

A stylized hummingbird study with long bill, compact body and swept translucent wing forms.

An authored animal study intended for lightweight botanical and editorial scenes. It is explicitly stylized rather than presented as a photoreal anatomical model.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/HummingbirdStudy.tsx` into your project, then render `<HummingbirdStudy />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
