# MESHVARA / Atelier Vessel

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Fashion

A thick optical fragrance vessel with an amber inner volume and dark architectural cap.

A fragrance presentation object built around glass thickness, liquid color, label restraint and product-shot proportions. Suitable for beauty, fashion and luxury editorial interfaces.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/AtelierVessel.tsx` into your project, then render `<AtelierVessel />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
