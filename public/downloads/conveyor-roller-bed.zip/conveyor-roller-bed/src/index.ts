export { default, ConveyorRollerBed } from './ConveyorRollerBed'
