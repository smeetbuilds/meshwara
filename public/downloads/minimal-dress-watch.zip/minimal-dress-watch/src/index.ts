export { default, MinimalDressWatch } from './MinimalDressWatch'
