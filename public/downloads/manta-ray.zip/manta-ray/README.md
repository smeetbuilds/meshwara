# MESHVARA / Manta Ray

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Animals

A dark manta study with wide planar wings, tapered tail and slow controlled banking motion.

An aquatic hero object designed around one unmistakable silhouette. The movement remains subtle and composed so the form reads as intentional visual art rather than a generic swimming loop.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/MantaRay.tsx` into your project, then render `<MantaRay />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
