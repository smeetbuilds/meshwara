export { default, MantaRay } from './MantaRay'
