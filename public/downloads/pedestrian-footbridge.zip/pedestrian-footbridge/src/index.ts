export { default, PedestrianFootbridge } from './PedestrianFootbridge'
