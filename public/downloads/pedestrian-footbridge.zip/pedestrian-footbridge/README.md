# MESHVARA / Pedestrian Footbridge

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Architecture

A slender pedestrian bridge with paired trusses, deck structure and guardrail rhythm.

A compact infrastructure asset balancing believable structural hierarchy with lightweight web geometry.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/PedestrianFootbridge.tsx` into your project, then render `<PedestrianFootbridge />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
