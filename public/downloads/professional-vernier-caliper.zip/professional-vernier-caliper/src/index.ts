export { default, ProfessionalVernierCaliper } from './ProfessionalVernierCaliper'
