export { default, DeltaPickRobot } from './DeltaPickRobot'
