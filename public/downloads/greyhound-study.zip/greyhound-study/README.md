# MESHVARA / Greyhound Study

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Animals

A lean standing greyhound with long leg chains, tapered muzzle and controlled athletic silhouette.

A stylized canine study focused on the breed’s narrow waist, deep chest, long limbs and quiet stance. It is intentionally presented as a designed animal form rather than an animation-ready realism claim.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/GreyhoundStudy.tsx` into your project, then render `<GreyhoundStudy />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
