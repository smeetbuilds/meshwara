# MESHVARA / Anesthesia Monitor

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Medical / Monitoring

A bedside anesthesia monitor with waveform display, rotary controls and mobile clinical stand.

A perioperative monitoring asset with readable physiological display hierarchy and a stable mobile equipment base for theatre and recovery scenes.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/AnesthesiaMonitor.tsx` into your project, then render `<AnesthesiaMonitor />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
