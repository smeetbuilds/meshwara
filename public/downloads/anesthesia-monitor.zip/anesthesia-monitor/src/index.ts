export { default, AnesthesiaMonitor } from './AnesthesiaMonitor'
