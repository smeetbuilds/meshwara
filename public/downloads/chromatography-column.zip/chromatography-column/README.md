# MESHVARA / Chromatography Column

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Scientific / Lab Instruments

A laboratory separation column with packed glass tube, valve heads and support stand.

A scientific process asset combining transparent vessel geometry, fittings and a clean support system for analytical-lab visualization.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ChromatographyColumn.tsx` into your project, then render `<ChromatographyColumn />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
