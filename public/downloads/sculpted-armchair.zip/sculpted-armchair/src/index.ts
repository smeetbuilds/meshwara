export { default, SculptedArmchair } from './SculptedArmchair'
