# MESHVARA / Quiet Pavilion

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Architecture

A restrained open pavilion balancing stone, warm material, glass and a single display object.

A compact architectural scene with deliberate structural rhythm, layered depth and gallery-like material contrast. Built to read clearly at both editorial hero scale and catalog-card scale.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/QuietPavilion.tsx` into your project, then render `<QuietPavilion />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
