# MESHVARA / Arc Floor Lamp

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Furniture

A long curve-authored metal arc rising from a weighted base into a warm suspended shade.

A lighting product built around a continuous support curve rather than segmented rods. The warm local emitter and quiet material pairing make it presentation-ready for premium interior scenes.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ArcFloorLamp.tsx` into your project, then render `<ArcFloorLamp />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
