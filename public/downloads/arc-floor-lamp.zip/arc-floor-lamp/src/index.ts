export { default, ArcFloorLamp } from './ArcFloorLamp'
