export { default, TwelveLeadECGMonitor } from './TwelveLeadECGMonitor'
