export { default, WirelessLavalierSystem } from './WirelessLavalierSystem'
