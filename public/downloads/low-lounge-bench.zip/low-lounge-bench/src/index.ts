export { default, LowLoungeBench } from './LowLoungeBench'
