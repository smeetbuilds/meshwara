# MESHVARA / Ceramic Relay

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Objects

A tactile ceramic control object with brass terminals and a single live indicator.

A compact industrial-design study balancing warm ceramic, dark machined metal and fine brass detail. Suitable for product, hardware and systems-oriented interfaces.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/CeramicRelay.tsx` into your project, then render `<CeramicRelay />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
