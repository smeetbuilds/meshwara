# MESHVARA / Orchid Stem

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Nature

A curve-authored orchid with three layered blossoms, asymmetrical leaves and compact ceramic planter.

A botanical object built around stem direction, petal layering and deliberate floral spacing. It extends the nature collection with a more delicate close-up plant language than the existing bonsai and tree studies.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/OrchidStem.tsx` into your project, then render `<OrchidStem />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
