export { default, SafetyLightCurtain } from './SafetyLightCurtain'
