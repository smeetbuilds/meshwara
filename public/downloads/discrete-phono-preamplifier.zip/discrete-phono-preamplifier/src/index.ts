export { default, DiscretePhonoPreamplifier } from './DiscretePhonoPreamplifier'
