# MESHVARA / Road Bike Crankset

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Vehicles / Cycling

A road crankset with hollow arms, double chainring, spindle and authored tooth rhythm.

A MESHVARA cycling asset built as a self-contained Three.js composition with authored proportions, deterministic detail and responsive presentation.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/RoadBikeCrankset.tsx` into your project, then render `<RoadBikeCrankset />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
