export { default, RockFormation } from './RockFormation'
