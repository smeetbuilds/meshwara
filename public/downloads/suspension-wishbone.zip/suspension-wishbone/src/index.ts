export { default, SuspensionWishbone } from './SuspensionWishbone'
