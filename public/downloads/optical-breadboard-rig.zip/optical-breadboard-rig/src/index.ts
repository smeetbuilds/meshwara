export { default, OpticalBreadboardRig } from './OpticalBreadboardRig'
