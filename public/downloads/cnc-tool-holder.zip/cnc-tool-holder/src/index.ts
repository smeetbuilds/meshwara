export { default, CNCToolHolder } from './CNCToolHolder'
