export { default, RoboticGripper } from './RoboticGripper'
