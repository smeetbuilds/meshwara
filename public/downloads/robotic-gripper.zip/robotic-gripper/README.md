# MESHVARA / Robotic Gripper

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Industrial

A compact articulated manipulator with machined joints, weighted links and a controlled two-finger end effector.

An automation-focused object using physically aligned link geometry and a subtle wrist articulation. The mechanical hierarchy is intentionally readable for robotics, manufacturing and engineering interfaces.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/RoboticGripper.tsx` into your project, then render `<RoboticGripper />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
