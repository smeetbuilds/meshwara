export { default, MotorizedSpindle } from './MotorizedSpindle'
