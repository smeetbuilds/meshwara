export { default, CinemaCameraCage } from './CinemaCameraCage'
