# MESHVARA / Signal Drone

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology

A compact aerial platform with engineered arm geometry, gimbal optics and four calibrated rotor assemblies.

A technology asset where motion is limited to the functional rotors while the body remains compositionally stable. The design is readable as hardware rather than abstract sci-fi decoration.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/SignalDrone.tsx` into your project, then render `<SignalDrone />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
