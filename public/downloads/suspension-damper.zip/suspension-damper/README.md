# MESHVARA / Suspension Damper

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Vehicles

A coil-over suspension unit with continuous helical spring, machined damper and mounting eyes.

An automotive component built with an authored continuous spring curve and layered hardware. Its proportions and material hierarchy are designed for technical automotive presentation.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/SuspensionDamper.tsx` into your project, then render `<SuspensionDamper />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
