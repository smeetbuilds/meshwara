export { default, SanitaryManifold } from './SanitaryManifold'
