export { default, BedsideTable } from './BedsideTable'
