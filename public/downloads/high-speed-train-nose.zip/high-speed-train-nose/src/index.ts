export { default, HighSpeedTrainNose } from './HighSpeedTrainNose'
