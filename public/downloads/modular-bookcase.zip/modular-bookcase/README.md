# MESHVARA / Modular Bookcase

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Furniture

A four-bay timber bookcase populated with staggered books and one quiet sculptural object.

A furniture asset built around shelf rhythm and restrained object placement instead of empty cabinetry. It is dense enough for interior scenes while still reading clearly in a card preview.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ModularBookcase.tsx` into your project, then render `<ModularBookcase />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
