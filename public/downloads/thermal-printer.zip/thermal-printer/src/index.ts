export { default, ThermalPrinter } from './ThermalPrinter'
