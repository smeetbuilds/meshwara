# MESHVARA / Carry Case

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Fashion

A compact travel case with radiused shell, vertical rails, telescopic handle, wheels and a single signal detail.

A travel-accessory study balancing hard-shell volume, wheel placement and hardware detail. Designed for fashion, travel and product interfaces without depending on texture maps.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/CarryCase.tsx` into your project, then render `<CarryCase />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
