export { default, StoneColonnade } from './StoneColonnade'
