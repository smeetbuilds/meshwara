export { default, MarinePropellerAssembly } from './MarinePropellerAssembly'
