# MESHVARA / Induction Cooktop

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology

A dark glass induction surface with calibrated zones, status light and a weighted cookware study.

A kitchen-technology object built around reflective surface quality, aligned heating zones and physically grounded cookware. Suitable for appliance, interior and hospitality experiences.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/InductionCooktop.tsx` into your project, then render `<InductionCooktop />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
