export { default, InductionCooktop } from './InductionCooktop'
