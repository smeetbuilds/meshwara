# MESHVARA / Olive Oil Bottle

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Food

A dark green optical bottle with warm oil volume, metallic cap and quiet unbranded front label.

A packaging asset designed around glass thickness, fill level and label proportion rather than branding. Suitable for food, retail and hospitality projects that need a premium neutral bottle.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/OliveOilBottle.tsx` into your project, then render `<OliveOilBottle />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
