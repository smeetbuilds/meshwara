export { default, DesertBoulderStudy } from './DesertBoulderStudy'
