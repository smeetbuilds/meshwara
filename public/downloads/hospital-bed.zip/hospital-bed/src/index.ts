export { default, HospitalBed } from './HospitalBed'
