# MESHVARA / Lounge Ottoman

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Furniture

A soft upholstered ottoman with rounded primary volume, floating top cushion and tapered support legs.

A quiet furniture object tuned around believable upholstery softness and restrained textile sheen. The low profile makes it useful in living-room, hospitality and product-layout compositions.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/LoungeOttoman.tsx` into your project, then render `<LoungeOttoman />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
