export { default, LoungeOttoman } from './LoungeOttoman'
