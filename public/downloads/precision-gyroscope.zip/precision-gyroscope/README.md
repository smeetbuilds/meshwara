# MESHVARA / Precision Gyroscope

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Industrial

A three-axis machined gimbal with independently driven rings and a dense illuminated rotor.

An instrumentation-grade kinetic object built around concentric tolerances, independent rotational cadence and controlled metal contrast. Designed for aerospace, engineering and systems interfaces.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/PrecisionGyroscope.tsx` into your project, then render `<PrecisionGyroscope />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
