export { default, OctopusFormStudy } from './OctopusFormStudy'
