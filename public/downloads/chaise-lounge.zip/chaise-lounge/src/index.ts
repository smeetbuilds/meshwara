export { default, SculpturalChaise } from './SculpturalChaise'
