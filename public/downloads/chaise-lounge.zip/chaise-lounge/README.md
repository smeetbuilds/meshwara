# MESHVARA / Sculptural Chaise

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Furniture / Seating

A low sculptural chaise with continuous upholstered sweep and recessed structural base.

A furniture piece built around a long ergonomic profile, soft edge treatment and restrained support geometry for residential/editorial interiors.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/SculpturalChaise.tsx` into your project, then render `<SculpturalChaise />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
