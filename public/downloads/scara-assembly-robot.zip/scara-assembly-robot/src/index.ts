export { default, SCARAAssemblyRobot } from './SCARAAssemblyRobot'
