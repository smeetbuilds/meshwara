export { default, CurbChainBracelet } from './CurbChainBracelet'
