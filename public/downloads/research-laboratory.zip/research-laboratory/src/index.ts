export { default, ResearchLaboratory } from './ResearchLaboratory'
