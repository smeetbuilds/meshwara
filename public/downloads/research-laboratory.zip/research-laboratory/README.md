# MESHVARA / Research Laboratory

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Scenes

A complete research bench vignette with analytical display, glass vessels, instrument arm and staged clinical light.

A deployable scientific interior fragment composed as one scene rather than unrelated lab props. Workbench depth, instrument spacing and localized lighting are balanced for technical editorial layouts.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ResearchLaboratory.tsx` into your project, then render `<ResearchLaboratory />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
