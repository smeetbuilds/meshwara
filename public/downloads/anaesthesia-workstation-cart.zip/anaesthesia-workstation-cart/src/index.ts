export { default, AnaesthesiaWorkstationCart } from './AnaesthesiaWorkstationCart'
