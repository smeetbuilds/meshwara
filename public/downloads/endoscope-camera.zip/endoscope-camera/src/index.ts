export { default, EndoscopeCamera } from './EndoscopeCamera'
