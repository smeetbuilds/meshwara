export { default, VacuumChamber } from './VacuumChamber'
