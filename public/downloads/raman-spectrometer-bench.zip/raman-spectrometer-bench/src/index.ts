export { default, RamanSpectrometerBench } from './RamanSpectrometerBench'
