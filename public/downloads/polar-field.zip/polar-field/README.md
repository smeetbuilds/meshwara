# MESHVARA / Polar Field

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Particles

A coherent particle shell with shader-driven drift and depth-scaled luminance.

A custom point shader distributes particles deterministically around a spherical field, preserving composition while adding subtle phase motion and additive depth.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/PolarField.tsx` into your project, then render `<PolarField />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
