# MESHVARA / Vector Needles

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Particles

Hundreds of directional elements resolving into a single flowing field.

A directional instancing study designed around field coherence and camera composition. Efficient enough for responsive use while retaining visual density.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/VectorNeedles.tsx` into your project, then render `<VectorNeedles />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
