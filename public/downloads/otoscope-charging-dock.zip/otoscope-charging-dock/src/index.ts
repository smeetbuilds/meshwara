export { default, OtoscopeChargingDock } from './OtoscopeChargingDock'
