# MESHVARA / Obsidian Monolith

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Objects

A carved black monolith with soft bevels and a luminous internal seam.

A restrained architectural object with premium product-shot lighting. Built to sit confidently in sparse typography-led layouts.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ObsidianMonolith.tsx` into your project, then render `<ObsidianMonolith />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
