export { default, ObsidianMonolith } from './ObsidianMonolith'
