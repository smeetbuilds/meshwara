export { default, SpatialSpeaker } from './SpatialSpeaker'
