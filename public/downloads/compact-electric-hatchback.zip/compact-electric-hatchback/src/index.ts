export { default, CompactElectricHatchback } from './CompactElectricHatchback'
