export { default, LaserInterferometer } from './LaserInterferometer'
