# MESHVARA / Cargo Bike

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Vehicles

A long-tail utility bicycle with authored tube frame, large cargo box and lightweight wheelset.

A mobility object that extends the existing bicycle language into a materially different utility form. Frame hierarchy, cargo volume and wheel spacing are composed for a believable practical silhouette.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/CargoBike.tsx` into your project, then render `<CargoBike />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
