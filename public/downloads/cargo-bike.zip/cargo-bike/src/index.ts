export { default, CargoBike } from './CargoBike'
