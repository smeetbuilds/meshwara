# MESHVARA / Espresso Set

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Food

A ceramic espresso cup, dark crema surface, metal spoon and two quiet steam lines composed as one tabletop object.

A compact food-and-hospitality asset with deliberate cup taper, saucer scale and restrained steam geometry. Designed for café, editorial and lifestyle interfaces without relying on image textures.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/EspressoSet.tsx` into your project, then render `<EspressoSet />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
