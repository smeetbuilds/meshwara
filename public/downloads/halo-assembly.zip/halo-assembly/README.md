# MESHVARA / Halo Assembly

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Objects

A calibrated orbital object built from concentric metal and glass systems.

A clean kinetic assembly for technology and product experiences. Every ring has its own motion cadence to create depth without visual noise.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/HaloAssembly.tsx` into your project, then render `<HaloAssembly />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
