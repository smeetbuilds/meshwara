# MESHVARA / Modular Desk

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Furniture

A warm work desk with machined legs, integrated storage, display, keyboard and compact tabletop vessel.

A workspace composition built as a complete furniture/product vignette rather than an empty table. Proportions and accessory placement are tuned for interior, productivity and workplace interfaces.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ModularDesk.tsx` into your project, then render `<ModularDesk />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
