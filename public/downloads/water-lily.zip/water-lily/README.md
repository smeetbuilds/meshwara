# MESHVARA / Water Lily

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Nature

A layered water-lily composition with radial petals, broad pad and a restrained optical water plane.

A nature study focused on controlled petal layering and readable radial form. Material choices keep the flower soft without relying on image textures or random procedural scatter.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/WaterLily.tsx` into your project, then render `<WaterLily />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
