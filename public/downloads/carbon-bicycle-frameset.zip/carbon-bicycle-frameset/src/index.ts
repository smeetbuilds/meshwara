export { default, CarbonBicycleFrameset } from './CarbonBicycleFrameset'
