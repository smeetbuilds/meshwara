export { default, WorkshopAirCompressor } from './WorkshopAirCompressor'
