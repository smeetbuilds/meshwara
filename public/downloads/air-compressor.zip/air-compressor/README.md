# MESHVARA / Workshop Air Compressor

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Industrial / Pneumatics

A compact workshop compressor with horizontal receiver, motor, pump head and regulator cluster.

An industrial utility object with functional pressure-vessel proportions, wheel supports and service components.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/WorkshopAirCompressor.tsx` into your project, then render `<WorkshopAirCompressor />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
