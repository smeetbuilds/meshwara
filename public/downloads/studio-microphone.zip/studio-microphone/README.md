# MESHVARA / Studio Microphone

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology

A large-diaphragm microphone with layered grille, dark body, shock cradle and desk-ready stand.

A studio-hardware object focused on believable component hierarchy: capsule, grille, body, mount and base. Fine metallic contrast lets it work in audio, podcast and creator-tool interfaces.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/StudioMicrophone.tsx` into your project, then render `<StudioMicrophone />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
