export { default, StudioMicrophone } from './StudioMicrophone'
