export { default, FlutedConsoleCabinet } from './FlutedConsoleCabinet'
