# MESHVARA / Mineral Pendant

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Jewelry

A curve-authored necklace carrying a warm-metal ring and cool mineral center stone.

A jewelry composition where the chain sag, bail and pendant hierarchy are deliberately authored. The mineral center adds optical depth without turning the piece into a generic gem demo.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/MineralPendant.tsx` into your project, then render `<MineralPendant />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
