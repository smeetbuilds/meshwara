export { default, MineralPendant } from './MineralPendant'
