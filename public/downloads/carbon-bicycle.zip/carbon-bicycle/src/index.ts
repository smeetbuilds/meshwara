export { default, CarbonBicycle } from './CarbonBicycle'
