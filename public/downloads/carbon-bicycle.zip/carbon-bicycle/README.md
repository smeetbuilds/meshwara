# MESHVARA / Carbon Bicycle

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Vehicles

A stripped-back performance bicycle with carbon frame triangle, narrow wheels, fork, cockpit and crank assembly.

A lightweight vehicle study built from correctly aligned structural tubes rather than arbitrary cylinders. Frame connections, wheel spacing and contact points are composed to preserve a believable bicycle silhouette.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/CarbonBicycle.tsx` into your project, then render `<CarbonBicycle />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
