# MESHVARA / Brutalist Stair

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Architecture

A concrete stair study with ten heavy treads, sparse rail and asymmetric vertical wall elements.

A structural interior fragment focused on rhythm, load and negative space. Concrete mass and metal rail contrast make the object work as an architectural scene rather than a generic staircase primitive.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/BrutalistStair.tsx` into your project, then render `<BrutalistStair />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
