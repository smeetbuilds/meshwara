export { default, DiagnosticScanner } from './DiagnosticScanner'
