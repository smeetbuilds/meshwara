# MESHVARA / Diagnostic Scanner

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Medical

A compact diagnostic imaging system with deep gantry, patient bed and calm clinical interface.

A medical-imaging scene focused on believable gantry thickness, bore depth, patient-table geometry and restrained interface lighting. Built for healthcare and scientific visualization contexts.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/DiagnosticScanner.tsx` into your project, then render `<DiagnosticScanner />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
