# MESHVARA / Transit Shelter

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Architecture / Civic

A compact urban shelter with cantilever roof, glazed wind screen and integrated bench.

A civic micro-architecture asset designed around real pedestrian scale, clear structural hierarchy and minimal street furniture.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/TransitShelter.tsx` into your project, then render `<TransitShelter />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
