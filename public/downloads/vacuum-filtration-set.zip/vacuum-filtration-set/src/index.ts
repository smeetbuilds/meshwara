export { default, VacuumFiltrationSet } from './VacuumFiltrationSet'
