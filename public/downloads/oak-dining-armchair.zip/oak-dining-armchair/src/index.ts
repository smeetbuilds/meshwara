export { default, OakDiningArmchair } from './OakDiningArmchair'
