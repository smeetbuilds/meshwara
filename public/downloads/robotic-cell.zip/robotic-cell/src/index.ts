export { default, RoboticWorkCell } from './RoboticWorkCell'
