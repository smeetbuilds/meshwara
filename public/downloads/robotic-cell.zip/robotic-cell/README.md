# MESHVARA / Robotic Work Cell

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Industrial / Automation

A fenced automation cell with six-axis robot, fixture table, light stack and safety gate.

A complete manufacturing vignette that communicates workstation hierarchy and safety zoning rather than showing an isolated robot arm.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/RoboticWorkCell.tsx` into your project, then render `<RoboticWorkCell />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
