export { default, CarbonRunningShoe } from './CarbonRunningShoe'
