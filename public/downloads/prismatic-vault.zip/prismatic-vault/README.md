# MESHVARA / Prismatic Vault

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Glass

Dense optical glass with spectral highlights and a precise internal core.

A refractive centerpiece that uses controlled transmission, thickness and chromatic material response without overwhelming the layout around it.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/PrismaticVault.tsx` into your project, then render `<PrismaticVault />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
