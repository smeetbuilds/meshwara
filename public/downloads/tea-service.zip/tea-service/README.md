# MESHVARA / Tea Service

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Food

A composed tray, teapot and paired cup service balancing ceramic, warm metal and wood.

A hospitality vignette designed as a complete serving composition. Vessel curvature, spout, handle and cup spacing are intentionally coordinated rather than independently placed props.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/TeaService.tsx` into your project, then render `<TeaService />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
