export { default, SignalSpeaker } from './SignalSpeaker'
