# MESHVARA / Signal Speaker

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology

A sculptural loudspeaker with a softly radiused enclosure, layered drivers and restrained signal motion.

An audio-product study with controlled proportions and tactile material contrast. Small amplitude driver motion adds presence without turning the object into a decorative animation.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/SignalSpeaker.tsx` into your project, then render `<SignalSpeaker />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
