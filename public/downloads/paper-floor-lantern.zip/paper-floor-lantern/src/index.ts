export { default, PaperFloorLantern } from './PaperFloorLantern'
