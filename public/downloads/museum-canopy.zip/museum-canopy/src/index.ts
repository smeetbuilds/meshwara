export { default, MuseumCanopy } from './MuseumCanopy'
