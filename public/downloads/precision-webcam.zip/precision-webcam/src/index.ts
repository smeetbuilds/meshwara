export { default, PrecisionWebcam } from './PrecisionWebcam'
