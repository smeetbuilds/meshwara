# MESHVARA / Precision Webcam

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology / Imaging

A premium webcam with layered optical barrel, privacy shutter and articulated display mount.

A compact imaging accessory with believable lens depth, machined housing and a physically plausible monitor clamp.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/PrecisionWebcam.tsx` into your project, then render `<PrecisionWebcam />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
