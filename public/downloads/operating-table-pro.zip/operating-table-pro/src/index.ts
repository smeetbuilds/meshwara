export { default, OperatingTablePro } from './OperatingTablePro'
