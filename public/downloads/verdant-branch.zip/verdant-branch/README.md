# MESHVARA / Verdant Branch

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Nature

A composed botanical stem with deterministic leaf spacing and almost imperceptible ambient movement.

A curve-authored botanical object that avoids randomized scatter in favor of designed phyllotactic rhythm, readable silhouette and restrained material response.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/VerdantBranch.tsx` into your project, then render `<VerdantBranch />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
