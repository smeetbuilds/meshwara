export { default, Daybed } from './Daybed'
