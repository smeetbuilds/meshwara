export { default, MechanicalNumpad } from './MechanicalNumpad'
