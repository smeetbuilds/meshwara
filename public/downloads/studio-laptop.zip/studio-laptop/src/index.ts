export { default, StudioLaptop } from './StudioLaptop'
