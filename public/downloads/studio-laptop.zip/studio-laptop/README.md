# MESHVARA / Studio Laptop

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology / Computing

A thin workstation laptop with machined chassis, keyboard deck and precisely hinged display.

A premium computing asset designed for desks, product showcases and interface compositions, with device-scale proportions and understated material separation.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/StudioLaptop.tsx` into your project, then render `<StudioLaptop />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
