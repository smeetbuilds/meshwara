# MESHVARA / Chromatic Reef

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Sculptures

A vertical colony of polished iridescent forms grown around a controlled axis.

An organic composition based on deterministic phyllotaxis rather than randomized placement. Each lobe contributes to a readable vertical silhouette and controlled spectral material response.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ChromaticReef.tsx` into your project, then render `<ChromaticReef />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
