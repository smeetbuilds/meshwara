export { default, SeparatoryFunnelRig } from './SeparatoryFunnelRig'
