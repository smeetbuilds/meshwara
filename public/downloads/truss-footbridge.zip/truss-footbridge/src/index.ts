export { default, TrussFootbridge } from './TrussFootbridge'
