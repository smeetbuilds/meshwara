export { default, LeatherSlingChair } from './LeatherSlingChair'
