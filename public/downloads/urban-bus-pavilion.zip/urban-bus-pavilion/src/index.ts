export { default, UrbanBusPavilion } from './UrbanBusPavilion'
