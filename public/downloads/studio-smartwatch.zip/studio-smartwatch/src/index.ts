export { default, StudioSmartwatch } from './StudioSmartwatch'
