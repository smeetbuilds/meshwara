# MESHVARA / Studio Smartwatch

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology

A compact wearable with sculpted case, digital crown, optical sensor body and layered display.

A clean wearable-tech study focused on case proportion, edge treatment and readable screen hierarchy.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/StudioSmartwatch.tsx` into your project, then render `<StudioSmartwatch />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
