export { default, DesktopSpirometer } from './DesktopSpirometer'
