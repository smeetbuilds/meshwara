export { default, LabCentrifuge } from './LabCentrifuge'
