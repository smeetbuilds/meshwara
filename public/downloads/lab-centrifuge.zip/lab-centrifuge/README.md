# MESHVARA / Lab Centrifuge

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Scientific

A compact bench centrifuge with optical lid, twelve-position rotor and a restrained digital interface.

A laboratory product asset combining a softened enclosure with visible rotor engineering. Tube placement is deterministic and the internal rotor motion stays measured enough for editorial product use.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/LabCentrifuge.tsx` into your project, then render `<LabCentrifuge />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
