export { default, ProfessionalSautePan } from './ProfessionalSautePan'
