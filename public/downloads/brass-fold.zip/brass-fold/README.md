# MESHVARA / Brass Fold

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Sculptures

Four machined brass ribbons interlock in a slow vertical fold.

A curve-authored sculpture with distinct ribbon paths, warm metallic response and restrained rotational drift. Intended for premium product and architecture compositions.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/BrassFold.tsx` into your project, then render `<BrassFold />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
