export { default, ProfessionalCameraGimbal } from './ProfessionalCameraGimbal'
