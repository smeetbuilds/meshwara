export { default, RoboticArm } from './RoboticArm'
