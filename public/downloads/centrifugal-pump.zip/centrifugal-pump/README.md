# MESHVARA / Centrifugal Pump

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Industrial / Fluid Systems

A process pump with volute casing, motor coupling, baseplate and flanged inlet/outlet.

An industrial fluid-handling asset using recognizable pump architecture and serviceable component separation.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/CentrifugalPump.tsx` into your project, then render `<CentrifugalPump />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
