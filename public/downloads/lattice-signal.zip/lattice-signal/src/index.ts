export { default, LatticeSignal } from './LatticeSignal'
