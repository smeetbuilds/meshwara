# MESHVARA / Lattice Signal

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Generative

A compact spatial lattice intersected by one luminous transmission ring.

A deterministic instanced node field designed for technical and scientific interfaces. Geometry is shared through instancing so visual density does not translate into excessive draw calls.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/LatticeSignal.tsx` into your project, then render `<LatticeSignal />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
