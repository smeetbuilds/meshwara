# MESHVARA / Dental Chair

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Medical

An articulated clinical chair with shaped cushions, powered base and integrated examination light.

A healthcare-equipment scene focused on patient-support geometry, articulation and clean clinical materials. The lighting arm and cushion stack are composed as one coherent treatment unit.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/DentalChair.tsx` into your project, then render `<DentalChair />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
