export { default, DentalChair } from './DentalChair'
