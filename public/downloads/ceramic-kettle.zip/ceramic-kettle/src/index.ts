export { default, CeramicKettle } from './CeramicKettle'
