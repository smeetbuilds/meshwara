# MESHVARA / Ceramic Kettle

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Food

A quiet ceramic kettle with curved dark handle, tapered spout, optical tip and warm metal trim.

A hospitality object focused on vessel curvature, spout proportion and handle continuity. The design is intentionally restrained for food, tea, lifestyle and editorial compositions.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/CeramicKettle.tsx` into your project, then render `<CeramicKettle />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
