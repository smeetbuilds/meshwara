export { default, GlassCapsule } from './GlassCapsule'
