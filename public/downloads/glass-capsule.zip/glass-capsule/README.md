# MESHVARA / Glass Capsule

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Glass

A thick optical capsule holding a warm metallic signal core.

A compact transmission study built around convincing thickness, clean refraction and a contrasting internal object. Tuned for hero cards without needing an external HDR file.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/GlassCapsule.tsx` into your project, then render `<GlassCapsule />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
