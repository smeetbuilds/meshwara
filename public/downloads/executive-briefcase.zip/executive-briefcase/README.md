# MESHVARA / Executive Briefcase

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Fashion

A structured leather briefcase with curve-authored handle, twin metal closures and grounded protective feet.

A business accessory built around material restraint, radiused shell geometry and hardware spacing. Intended for premium fashion, travel and professional product interfaces.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ExecutiveBriefcase.tsx` into your project, then render `<ExecutiveBriefcase />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
