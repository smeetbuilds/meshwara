# MESHVARA / Travertine Console

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Furniture

A heavy stone console balanced by dark metal, warm detail and a restrained tabletop object.

A furniture composition focused on thickness, proportion, support rhythm and material contrast. Designed to feel like an interior-design product vignette rather than a generic table primitive.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/TravertineConsole.tsx` into your project, then render `<TravertineConsole />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
