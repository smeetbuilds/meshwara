export { default, BentwoodRockingChair } from './BentwoodRockingChair'
