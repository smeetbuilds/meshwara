export { default, ProductPhotographyStudio } from './ProductPhotographyStudio'
