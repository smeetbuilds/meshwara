# MESHVARA / Waveform Column

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Generative

A stacked ring column whose profile reads like a physicalized audio waveform.

A parametric vertical composition with phase-offset ring scales and micro-rotation. The movement is intentionally measured so it can live beside typography without becoming visual noise.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/WaveformColumn.tsx` into your project, then render `<WaveformColumn />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
