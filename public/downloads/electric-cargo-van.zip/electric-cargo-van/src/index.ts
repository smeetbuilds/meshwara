export { default, ElectricCargoVan } from './ElectricCargoVan'
