export { default, StudioHeadphones } from './StudioHeadphones'
