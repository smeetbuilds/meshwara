# MESHVARA / Studio Headphones

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology

A premium over-ear headphone study with a curve-authored headband, layered cups and warm machined accents.

A product-ready audio object emphasizing cushion depth, headband curvature, yoke proportions and material hierarchy. Built for music, hardware and editorial launch compositions.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/StudioHeadphones.tsx` into your project, then render `<StudioHeadphones />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
