# MESHVARA / Aero Runner

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Fashion

A performance sneaker study with a beveled sculpted sole, layered upper and a restrained luminous speed line.

A footwear-focused hero object built from authored side profiles rather than stacked primitives. The silhouette, heel volume, lacing rhythm and sole proportion are composed to read like a deliberate industrial-design study.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/AeroRunner.tsx` into your project, then render `<AeroRunner />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
