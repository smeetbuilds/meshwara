# MESHVARA / Bonsai Study

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Nature

A curve-authored bonsai with weighted trunk, asymmetric branch structure and compact layered canopy.

A botanical asset designed around branch hierarchy and silhouette instead of random foliage scattering. Canopy masses are deterministic so the published preview and downloaded source remain visually identical.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/BonsaiStudy.tsx` into your project, then render `<BonsaiStudy />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
