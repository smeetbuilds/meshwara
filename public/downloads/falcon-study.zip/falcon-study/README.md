# MESHVARA / Falcon Study

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Animals

A perched falcon study with layered flight feathers, weighted chest, focused head and warm talon detail.

A stylized animal asset built around silhouette discipline and readable avian anatomy rather than decorative noise. Wing layering, head proportion and perch stance are composed for premium editorial use.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/FalconStudy.tsx` into your project, then render `<FalconStudy />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
