export { default, FalconStudy } from './FalconStudy'
