export { default, CreativeWorkstationScene } from './CreativeWorkstationScene'
