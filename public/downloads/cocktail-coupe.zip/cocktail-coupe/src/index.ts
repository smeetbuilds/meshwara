export { default, CocktailCoupe } from './CocktailCoupe'
