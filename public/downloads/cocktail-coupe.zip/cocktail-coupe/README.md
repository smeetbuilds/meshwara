# MESHVARA / Cocktail Coupe

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Food

A custom-profile coupe with transparent bowl, warm cocktail layer and minimal citrus garnish.

A hospitality asset using lathed glass geometry so the stem, bowl and rim read as one designed profile. The liquid and garnish are deliberately restrained for premium bar and restaurant interfaces.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/CocktailCoupe.tsx` into your project, then render `<CocktailCoupe />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
