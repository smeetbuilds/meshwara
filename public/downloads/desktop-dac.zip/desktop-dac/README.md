# MESHVARA / Desktop DAC

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology / Audio

A desktop converter and headphone amplifier with machined volume control and metering display.

A compact reference-audio object for workstation and listening-room scenes, using disciplined front-panel hierarchy and metal/glass contrast.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/DesktopDAC.tsx` into your project, then render `<DesktopDAC />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
