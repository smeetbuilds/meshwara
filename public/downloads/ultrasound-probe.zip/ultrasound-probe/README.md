# MESHVARA / Ultrasound Probe

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Medical / Diagnostic

A curved-array ultrasound transducer with ergonomic handle, cable strain relief and connector block.

A diagnostic imaging component with a recognizable acoustic head and carefully routed cable geometry.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/UltrasoundProbe.tsx` into your project, then render `<UltrasoundProbe />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
