# MESHVARA / Carbon Spine

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Objects

A modular black structure with machined rhythm and controlled rotation.

A dark industrial object made from repeating precision modules. Its silhouette stays readable on both wide desktop and narrow mobile compositions.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/CarbonSpine.tsx` into your project, then render `<CarbonSpine />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
