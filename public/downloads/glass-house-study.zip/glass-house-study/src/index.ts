export { default, GlassHouseStudy } from './GlassHouseStudy'
