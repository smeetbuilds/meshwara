# MESHVARA / Pendant Cluster

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Furniture

A three-light pendant composition with varied drop heights and translucent sculptural shades.

A lighting asset intended for interior scenes where hierarchy and suspended rhythm matter more than decorative noise.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/PendantCluster.tsx` into your project, then render `<PendantCluster />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
