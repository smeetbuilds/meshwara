export { default, StoneCoffeeTable } from './StoneCoffeeTable'
