export { default, CounterHeightStool } from './CounterHeightStool'
