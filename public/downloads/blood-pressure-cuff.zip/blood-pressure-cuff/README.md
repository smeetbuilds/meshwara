# MESHVARA / Blood Pressure Cuff

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Medical / Diagnostic

A digital sphygmomanometer with soft cuff, hose, display body and start control.

A diagnostic healthcare asset with believable cuff geometry and clean device hierarchy for clinic and telehealth scenes.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/BloodPressureCuff.tsx` into your project, then render `<BloodPressureCuff />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
