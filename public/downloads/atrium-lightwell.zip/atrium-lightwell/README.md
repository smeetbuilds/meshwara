# MESHVARA / Atrium Lightwell

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Architecture

A compact atrium fragment with skylight grid, pale walls, low bench and one planted stone vessel.

A spatial architectural scene designed around daylight, wall planes and readable human-scale furniture proportions. It is static by design so the geometry can support typography and navigation around it.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/AtriumLightwell.tsx` into your project, then render `<AtriumLightwell />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
