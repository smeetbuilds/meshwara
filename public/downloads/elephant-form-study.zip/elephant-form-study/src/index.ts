export { default, ElephantFormStudy } from './ElephantFormStudy'
