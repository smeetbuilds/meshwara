# MESHVARA / Mirrorless Camera

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology / Imaging

A compact full-frame camera with articulated lens mount, grip geometry and calibrated control surfaces.

A product-grade imaging object built around recognizable camera proportions, layered lens barrels and restrained hardware detail for editorial technology scenes.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/MirrorlessCamera.tsx` into your project, then render `<MirrorlessCamera />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
