export { default, ArchitectDeskLamp } from './ArchitectDeskLamp'
