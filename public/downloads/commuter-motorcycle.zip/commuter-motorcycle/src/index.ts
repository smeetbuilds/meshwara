export { default, CommuterMotorcycle } from './CommuterMotorcycle'
