export { default, CliffCabinStudy } from './CliffCabinStudy'
