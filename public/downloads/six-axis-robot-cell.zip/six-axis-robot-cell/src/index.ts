export { default, SixAxisRobotCell } from './SixAxisRobotCell'
