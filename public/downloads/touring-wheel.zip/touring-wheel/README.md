# MESHVARA / Touring Wheel

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Vehicles

A road-wheel study with deep tire, machined rim, radial spokes, hub fasteners and warm caliper detail.

An automotive component designed around wheel depth, spoke spacing and metallic hierarchy. Slow wheel motion keeps the engineering legible instead of turning the asset into a decorative spinner.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/TouringWheel.tsx` into your project, then render `<TouringWheel />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
