export { default, CourtyardVillaStudy } from './CourtyardVillaStudy'
