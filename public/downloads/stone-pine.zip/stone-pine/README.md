# MESHVARA / Stone Pine

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Nature

A stylized stone-pine study with curve-authored trunk, deterministic branch rhythm and dense geometric canopy.

A nature asset that prioritizes silhouette and branch structure over random foliage scatter. Deterministic phyllotactic placement keeps every preview and download visually identical.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/StonePine.tsx` into your project, then render `<StonePine />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
