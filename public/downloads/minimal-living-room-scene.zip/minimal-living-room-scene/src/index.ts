export { default, MinimalLivingRoomScene } from './MinimalLivingRoomScene'
