# MESHVARA / Glazed Window Bay

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Architecture / Facade

A deep facade bay with mullion grid, recessed glass and projecting stone frame.

A reusable architectural facade module with layered depth and realistic framing logic for residential and civic compositions.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/GlazedWindowBay.tsx` into your project, then render `<GlazedWindowBay />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
