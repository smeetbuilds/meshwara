export { default, GlazedWindowBay } from './GlazedWindowBay'
