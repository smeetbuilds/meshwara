# MESHVARA / Aperture Module

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology

A camera-inspired optical module with machined rings, layered glass and a compact iris assembly.

A dense technical object for imaging and hardware interfaces. The composition emphasizes concentric tolerances, optical depth and precision detailing rather than generic sci-fi decoration.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ApertureModule.tsx` into your project, then render `<ApertureModule />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
