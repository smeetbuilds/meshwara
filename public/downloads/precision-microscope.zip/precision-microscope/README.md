# MESHVARA / Precision Microscope

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Scientific

A laboratory microscope with weighted base, articulated stand, optical tube, turret and specimen stage.

A scientific-instrument study where mechanical proportions, optical axis, controls and stage hierarchy are composed to read immediately as professional lab hardware rather than generic cylinders.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/PrecisionMicroscope.tsx` into your project, then render `<PrecisionMicroscope />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
