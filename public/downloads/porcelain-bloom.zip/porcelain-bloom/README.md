# MESHVARA / Porcelain Bloom

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Sculptures

A soft radial object with ceramic petals and subtle translucent edges.

An organic sculptural form intended for fashion, fragrance and editorial layouts. The motion is intentionally slow and asymmetric.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/PorcelainBloom.tsx` into your project, then render `<PorcelainBloom />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
