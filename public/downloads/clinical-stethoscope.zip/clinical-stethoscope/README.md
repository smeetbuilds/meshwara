# MESHVARA / Clinical Stethoscope

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Medical

A clinical stethoscope with curved binaural tubes, flexible line and weighted chestpiece.

A healthcare object built around recognizable functional proportion and clean material separation.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ClinicalStethoscope.tsx` into your project, then render `<ClinicalStethoscope />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
