export { default, ClinicalStethoscope } from './ClinicalStethoscope'
