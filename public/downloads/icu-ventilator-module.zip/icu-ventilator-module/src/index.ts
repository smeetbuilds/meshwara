export { default, ICUVentilatorModule } from './ICUVentilatorModule'
