export { default, AdventureMotorcycleADV } from './AdventureMotorcycleADV'
