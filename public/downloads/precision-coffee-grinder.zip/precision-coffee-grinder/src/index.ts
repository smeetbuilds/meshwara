export { default, PrecisionCoffeeGrinder } from './PrecisionCoffeeGrinder'
