export { default, SculpturalHandbag } from './SculpturalHandbag'
