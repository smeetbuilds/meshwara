# MESHVARA / Sculptural Handbag

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Fashion

A compact leather bag with radiused body, curve-authored handle and restrained metal closure.

A fashion accessory built around silhouette, handle continuity and material tactility rather than texture-heavy branding. Intended for premium editorial and commerce hero layouts.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/SculpturalHandbag.tsx` into your project, then render `<SculpturalHandbag />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
