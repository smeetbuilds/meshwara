export { default, AeroSideMirror } from './AeroSideMirror'
