# MESHVARA quality contract

- Live catalog WebGL preview
- Automatic bounds/framing
- ACES filmic tone mapping
- Responsive DPR
- Reduced-motion support
- Deterministic source construction
- SHA-256-manifested download ZIP
- Scene source bytes: 1416

This automated contract complements visual art-direction review.
