export { default, TouringMotorcycleGT } from './TouringMotorcycleGT'
