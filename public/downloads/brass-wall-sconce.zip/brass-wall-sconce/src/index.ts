export { default, BrassWallSconce } from './BrassWallSconce'
