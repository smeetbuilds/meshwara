export { default, ThreeDrawerChest } from './ThreeDrawerChest'
