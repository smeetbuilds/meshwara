export { default, UpholsteredEntryBench } from './UpholsteredEntryBench'
