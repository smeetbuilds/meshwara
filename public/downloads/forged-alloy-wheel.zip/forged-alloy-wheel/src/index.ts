export { default, ForgedAlloyWheel } from './ForgedAlloyWheel'
