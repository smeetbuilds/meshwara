export { default, ContemporarySurgicalSuite } from './ContemporarySurgicalSuite'
