export { default, HelicopterRotorHead } from './HelicopterRotorHead'
