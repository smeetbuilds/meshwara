# MESHVARA / Bar Trolley

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Furniture / Storage

A two-tier drinks trolley with tubular frame, bottle rail and large rolling wheels.

A hospitality furniture asset with functional wheel geometry, tray hierarchy and slender metal construction.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/BarTrolley.tsx` into your project, then render `<BarTrolley />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
