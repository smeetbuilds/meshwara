export { default, PrecisionTelescope } from './PrecisionTelescope'
