# MESHVARA / Alpine Cabin

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Architecture

A compact timber cabin with steep roof, optical window, chimney and deterministic evergreen grouping.

A small architectural landscape asset balancing cabin proportion, roof mass, glazing and nearby vegetation. The composition is deterministic and designed to remain legible in constrained responsive previews.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/AlpineCabin.tsx` into your project, then render `<AlpineCabin />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
