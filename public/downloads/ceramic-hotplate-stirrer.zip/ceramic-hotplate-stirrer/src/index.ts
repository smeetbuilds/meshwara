export { default, CeramicHotplateStirrer } from './CeramicHotplateStirrer'
