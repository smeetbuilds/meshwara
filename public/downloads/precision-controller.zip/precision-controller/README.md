# MESHVARA / Precision Controller

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology

A sculpted game controller with asymmetric sticks, shoulder forms and tactile control grouping.

A product-grade controller study built around ergonomic silhouette and explicit control geometry rather than icon-like simplification.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/PrecisionController.tsx` into your project, then render `<PrecisionController />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
