export { default, OwlStudy } from './OwlStudy'
