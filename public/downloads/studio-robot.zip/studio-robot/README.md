# MESHVARA / Studio Robot

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology

A compact articulated studio robot with weighted base, shoulder links, expressive sensor head and support arms.

A robotics object designed around mechanical hierarchy and restrained character. Subtle head motion provides life without pretending to be a fully rigged humanoid character asset.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/StudioRobot.tsx` into your project, then render `<StudioRobot />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
