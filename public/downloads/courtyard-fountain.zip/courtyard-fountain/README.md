# MESHVARA / Courtyard Fountain

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Architecture

A low circular basin with rotating water sheen, central stone form and six restrained water jets.

A landscape-architecture focal object designed around quiet symmetry and material weight. Water treatment stays deliberately subtle so the piece can live beside typography without becoming a simulation demo.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/CourtyardFountain.tsx` into your project, then render `<CourtyardFountain />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
