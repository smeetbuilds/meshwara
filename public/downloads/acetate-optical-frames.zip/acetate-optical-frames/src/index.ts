export { default, AcetateOpticalFrames } from './AcetateOpticalFrames'
