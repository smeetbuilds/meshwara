# MESHVARA / Stone Washbasin

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Furniture

A lathed stone vessel basin with shallow water surface, pedestal and brushed-metal tap.

A bathroom product study using a custom radial profile instead of a generic cylinder. Material weight, rim thickness, water plane and tap geometry are composed for hospitality and interior-design scenes.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/StoneWashbasin.tsx` into your project, then render `<StoneWashbasin />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
