export { default, StoneWashbasin } from './StoneWashbasin'
