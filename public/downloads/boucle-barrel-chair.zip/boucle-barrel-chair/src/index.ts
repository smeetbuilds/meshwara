export { default, BoucleBarrelChair } from './BoucleBarrelChair'
