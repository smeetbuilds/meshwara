# MESHVARA / Mercury Fold

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Sculptures

A liquid-metal ribbon folded into a slow, architectural loop.

A polished editorial sculpture built around layered metallic forms, restrained motion and studio-grade reflections. Designed for luxury landing pages and full-bleed hero compositions.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/MercuryFold.tsx` into your project, then render `<MercuryFold />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
