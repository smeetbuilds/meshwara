# MESHVARA / Meditation Courtyard

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Scenes

A quiet architectural courtyard with shallow water, bench, planted vessel and controlled daylight.

A complete spatial scene designed around negative space, human-scale furniture and one botanical focal point. It is deliberately calm enough to host typography and navigation around it.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/MeditationCourtyard.tsx` into your project, then render `<MeditationCourtyard />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
