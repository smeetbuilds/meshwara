# MESHVARA / Sourdough Loaf

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Food

A broad artisan loaf with warm crust, raised oval body and four clean scoring cuts.

A single food object designed around convincing bakery proportion and scoring rhythm. It intentionally avoids noisy displacement and phototexture dependence so the source stays lightweight and editable.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/SourdoughLoaf.tsx` into your project, then render `<SourdoughLoaf />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
