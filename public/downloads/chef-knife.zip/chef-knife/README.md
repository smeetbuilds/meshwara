# MESHVARA / Chef Knife

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Food

A wide chef blade with authored belly profile, beveled steel, dark handle and exposed rivets.

A kitchen-tool asset whose silhouette is generated from a deliberate blade profile rather than a box primitive. Edge geometry and handle proportions are composed for culinary interfaces and product storytelling.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/ChefKnife.tsx` into your project, then render `<ChefKnife />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
