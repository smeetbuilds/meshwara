export { default, ObservatoryRoofDeck } from './ObservatoryRoofDeck'
