# MESHVARA / Analytical Balance

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Scientific / Lab Instruments

A laboratory balance with enclosed weighing chamber, precision pan and low front display.

A metrology asset with a transparent draft shield and believable weighing geometry for research and quality-control scenes.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/AnalyticalBalance.tsx` into your project, then render `<AnalyticalBalance />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
