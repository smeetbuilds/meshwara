export { default, OpalPendantGlobe } from './OpalPendantGlobe'
