# MESHVARA / City Tram

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Vehicles

A compact urban tram with rounded body, dark window band, wheelsets and roof collector hardware.

A transit vehicle study built around clean public-transport proportions and a readable side profile. It works as a mobility hero object without the visual clutter of a full rail environment.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/CityTram.tsx` into your project, then render `<CityTram />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
