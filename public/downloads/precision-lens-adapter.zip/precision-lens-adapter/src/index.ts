export { default, PrecisionLensAdapter } from './PrecisionLensAdapter'
