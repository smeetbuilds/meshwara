export { default, EquatorialTelescopeMount } from './EquatorialTelescopeMount'
