export { default, CoastalObservationShelter } from './CoastalObservationShelter'
