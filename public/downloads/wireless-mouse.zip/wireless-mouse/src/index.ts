export { default, WirelessMouse } from './WirelessMouse'
