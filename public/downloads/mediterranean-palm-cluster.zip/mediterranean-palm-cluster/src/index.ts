export { default, MediterraneanPalmCluster } from './MediterraneanPalmCluster'
