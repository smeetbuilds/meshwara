export { default, UltrasoundConsolePro } from './UltrasoundConsolePro'
