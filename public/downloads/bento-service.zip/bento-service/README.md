# MESHVARA / Bento Service

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Food

A four-compartment bento composition with rice, salmon, greens and warm side elements.

A complete food-service scene built for clear compartment hierarchy and balanced color. The content is stylized enough for performance while still reading immediately as a considered meal presentation.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/BentoService.tsx` into your project, then render `<BentoService />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
