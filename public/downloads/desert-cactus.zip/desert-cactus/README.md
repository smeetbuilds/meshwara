# MESHVARA / Desert Cactus

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Nature

A sculptural saguaro form with asymmetric branching, fine deterministic spines and earthen planter.

A dry-climate botanical asset emphasizing vertical balance and branch rhythm. The deterministic spine detail adds scale without random placement or texture dependency.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/DesertCactus.tsx` into your project, then render `<DesertCactus />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
