# MESHVARA / Match Basketball

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Sports

A regulation-inspired basketball with recessed seam channels and fine surface segmentation.

A clean sports-ball asset built for responsive hero scenes without relying on bitmap texture detail.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/MatchBasketball.tsx` into your project, then render `<MatchBasketball />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
