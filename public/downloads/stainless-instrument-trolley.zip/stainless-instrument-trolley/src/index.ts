export { default, StainlessInstrumentTrolley } from './StainlessInstrumentTrolley'
