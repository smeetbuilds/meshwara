# MESHVARA / Cantilever Bridge

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Architecture

A compact bridge study with weighted deck, twin pylons, suspended cables and stone supports.

A structural architecture asset that preserves a clear load-bearing hierarchy at small scale. Cable curves, support spacing and deck proportions are designed as one readable system.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/CantileverBridge.tsx` into your project, then render `<CantileverBridge />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
