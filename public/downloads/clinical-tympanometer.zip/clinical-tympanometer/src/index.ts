export { default, ClinicalTympanometer } from './ClinicalTympanometer'
