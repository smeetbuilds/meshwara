export { default, SmartHomeHub } from './SmartHomeHub'
