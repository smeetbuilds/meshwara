export { default, SurgicalLightArrayPro } from './SurgicalLightArrayPro'
