export { default, CompactCrossbodyBag } from './CompactCrossbodyBag'
