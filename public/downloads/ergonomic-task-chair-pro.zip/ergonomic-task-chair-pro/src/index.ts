export { default, ErgonomicTaskChairPro } from './ErgonomicTaskChairPro'
