# MESHVARA / Field Camera

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology

A complete compact camera body with optical lens stack, grip, viewfinder, controls and restrained lens color.

A full imaging-hardware object that expands the optical-module family into a complete product. Body proportions, grip, control positions and lens depth are composed for premium technical presentation.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/FieldCamera.tsx` into your project, then render `<FieldCamera />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
