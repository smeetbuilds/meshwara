export { default, DigitalOphthalmoscope } from './DigitalOphthalmoscope'
