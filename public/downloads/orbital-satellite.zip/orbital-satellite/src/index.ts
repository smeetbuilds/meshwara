export { default, OrbitalSatellite } from './OrbitalSatellite'
