# MESHVARA / Orbital Satellite

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Technology

A compact orbital platform with paired solar wings, high-gain dish and restrained instrument lighting.

A space-hardware object built around clear bus, solar-array and antenna hierarchy. Motion remains slow and composed so the asset can function as a hero object instead of a toy animation.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/OrbitalSatellite.tsx` into your project, then render `<OrbitalSatellite />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
