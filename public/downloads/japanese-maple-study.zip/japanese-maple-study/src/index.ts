export { default, JapaneseMapleStudy } from './JapaneseMapleStudy'
