export { default, ElectricScooter } from './ElectricScooter'
