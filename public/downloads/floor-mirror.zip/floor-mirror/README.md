# MESHVARA / Floor Mirror

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Furniture / Decor

A full-height leaning mirror with slender metal frame, back support and physically reflective face.

A minimal interior decor asset built for bedrooms, retail and hospitality scenes, with intentional lean angle and stable floor contact.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/FloorMirror.tsx` into your project, then render `<FloorMirror />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
