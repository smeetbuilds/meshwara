export { default, FloorMirror } from './FloorMirror'
