export { default, ElectricVehicleWorkshop } from './ElectricVehicleWorkshop'
