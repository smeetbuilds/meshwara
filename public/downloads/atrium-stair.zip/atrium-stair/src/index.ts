export { default, AtriumStair } from './AtriumStair'
