# MESHVARA / Atrium Stair

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Architecture / Interior

A suspended atrium stair with folded flights, landing plate and fine balustrade rhythm.

An architectural fragment built for interior visualization, prioritizing believable rise/run, structural thickness and controlled guardrail density.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/AtriumStair.tsx` into your project, then render `<AtriumStair />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
