export { default, MuseumStair } from './MuseumStair'
