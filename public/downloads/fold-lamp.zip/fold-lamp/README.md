# MESHVARA / Fold Lamp

> Free production-grade Three.js asset by Aahav Labs.
> https://aahavlabs.in · hi@aahavlabs.in

**Category:** Furniture

A compact table lamp balancing dark metal, warm brass and a softly transmitted shade.

A lighting-object study with a restrained industrial silhouette and localized glow. Designed for interior, product and editorial layouts that need a believable warm focal object.

## Install

```bash
bun add three@0.185.1 @react-three/fiber@9.7.0 @react-three/drei@10.7.7 react@19.2.8
```

## Use

Copy `src/Scene.tsx` and `src/FoldLamp.tsx` into your project, then render `<FoldLamp />`. The wrapper includes automatic bounds/framing, ACES filmic tone mapping, responsive DPR, pointer inertia, a studio environment, and `prefers-reduced-motion` handling.

## License

MIT. Free for personal and commercial projects. Keep the included license notice with substantial redistributed source.
