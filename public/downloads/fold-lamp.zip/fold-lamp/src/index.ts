export { default, FoldLamp } from './FoldLamp'
