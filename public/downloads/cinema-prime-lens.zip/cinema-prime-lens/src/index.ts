export { default, CinemaPrimeLens } from './CinemaPrimeLens'
